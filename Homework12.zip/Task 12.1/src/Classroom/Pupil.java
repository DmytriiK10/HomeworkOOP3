package Classroom;

public class Pupil {


    void study() {

        System.out.println("Ученнь вчиться на ");

    }

void read() {

    System.out.println("Ученнь читає на ");
 

}
void write() {

    System.out.println("Ученнь пише на ");
}
void relax() {

    System.out.println("Ученнь відпочиває на ");
}
}
