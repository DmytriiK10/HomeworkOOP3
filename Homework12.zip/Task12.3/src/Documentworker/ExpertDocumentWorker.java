package Documentworker;

public class ExpertDocumentWorker extends ProDocumentWorker {

    @Override
    public void saveDocument() {

        System.out.println("Збережений у новому форматі ");
    }
}
