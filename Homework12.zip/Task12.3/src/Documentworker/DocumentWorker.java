package Documentworker;

public class DocumentWorker {
    public void openDocument() {
        System.out.println("Документ відкритий ");
    }
    public void editDocument() {
        System.out.println("Правка документа доступна у версії PRO ");

    }
    public void saveDocument() {
        System.out.println("Збереження документа доступне у версії PRO ");

    }


}
