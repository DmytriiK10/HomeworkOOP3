public final class  Ship extends Vehicle {
    @Override
    public void InformationTransport() {
        super.InformationTransport();
        int passengers = 100;
        int portregistraition = 157;
        System.out.println("Пассажири : " + passengers);
        System.out.println("Порт регістрації : " + portregistraition);


    }


}
