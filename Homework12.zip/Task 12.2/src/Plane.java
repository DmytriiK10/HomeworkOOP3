public final class Plane extends Vehicle {

    @Override
    public void InformationTransport() {
        super.InformationTransport();
    int high = 6;
    int passengers = 150;
    System.out.println("Висота : " + high);
    System.out.println("Пассажири : " + passengers);








    }


}
