public final class Car extends Vehicle {
    }

